# Write a Python program that prompts the user to enter a positive integer and then prints
# all the numbers from 1 to that number using a while loop

m = int(input("Enter the number "))
n = 1
while n <= m:
    print(n)
    n = n + 1
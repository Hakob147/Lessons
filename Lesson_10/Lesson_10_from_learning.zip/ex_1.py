n = 1
while n < 11:
    print("I love python")
    n = n + 1
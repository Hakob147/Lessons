# Write a while loop that sums all the numbers up to 10.

n = 1
sum = 0
while n < 11:
    sum = sum + n
    n = n + 1
print(sum)
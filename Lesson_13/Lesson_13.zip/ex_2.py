# Write a Python program to find if a given string starts with a given
# character using Lambda

name = lambda a,b: a == b[0]
x = name ("h","hello")
print(x)
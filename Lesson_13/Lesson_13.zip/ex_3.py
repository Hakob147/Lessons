# Write a Python program to check whether a given string is number or
# not using Lambda.

number_check = lambda x: x.isdigit()
name = number_check("123")
print(name)

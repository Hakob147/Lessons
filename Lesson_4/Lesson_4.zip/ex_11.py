# Given a real number, round it to the nearest whole

number=float(input("Enter the rounded number "))
print(int(number+0.5))
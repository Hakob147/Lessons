#nput a natural number N and output its last digit

natural_number=input("Enter the natural number ")
print(natural_number[-1])

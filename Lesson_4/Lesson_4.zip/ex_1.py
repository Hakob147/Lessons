#Input two integers and print out their sum. Preserve the exact format from
#the examples (e.g. the output should contain exactly three lines)

first_number=input("Enter the first number ")
second_number=input("Enter the second number ")
sum=int(first_number)+int(second_number)
print("Sum of two numbers is",sum)
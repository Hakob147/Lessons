#Input a two-digit natural number and output the sum of its digits. You can
#assume that the input will be a two-digit number and need not check that
#programmatically

two_digits=input("Enter the two digits number ")
print(int(two_digits[0])+int(two_digits[1]))
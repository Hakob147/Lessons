# .Write a python function which will get circle_r(շառավիղ)
# Compute the area of a circle.

# Area = П * r^2

import math
def area(number):
    return math.pi * number**2

x = area(5)
print(x)
#Check if a value exists in a dictionary

result = False
value = 1050
tel = {"jack": 1020, "sape": 1030}
tel ["guido"] = 1040
for k, v in tel.items():
    if value == v:
        result = True
print(result)

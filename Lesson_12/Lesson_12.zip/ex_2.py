# Write a function that takes a base and an exponent and returns the result of raising the
# base to the exponent

def power_function(a,b):
    return (a**b)
x=power_function(2,3)
print(x)
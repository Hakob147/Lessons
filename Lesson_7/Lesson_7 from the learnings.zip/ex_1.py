# Write a Python script that takes input from the user and displays that input back in upper
# and lower cases.

name = input("Enter the name ")
upper_name = name.upper()
lower_name = name.lower()
print(upper_name)
print(lower_name)
# Write a Python program to remove the n-th index character from a nonempty string

#Sample string: ‘abcdefgh’
# n - 3

x="abcdefgh"
print(x[:3]+x[4:])

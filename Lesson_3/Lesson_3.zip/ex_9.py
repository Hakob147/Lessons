#Append new string in the middle of a given (even number of characters) string
#Sample = ‘python’
#new_string = ‘new’

x="python"
y="new"
print(x[:3]+y+x[-3:])


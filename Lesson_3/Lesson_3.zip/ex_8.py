# Create a string made of the first, middle and last character of given string with odd number of symbols

# Sample = ‘Sevak’

name='Sevak'
print(name[0]+name[2]+name[4])


# Write a Python program to print the floating numbers upto 2 decimal places
# (number must be not greater than 10)

# Sample = 9.5748

#Option 1, if not use Round function
x=9.5748
print(x-0.0048)

#Option 2, with Round function
print(round(x,2))

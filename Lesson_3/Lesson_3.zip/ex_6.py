# Write a Python function to get a string made of its first three characters of a specified string. If
# the length of the string is less than 3 then return the original string

# Sample ='python'

x='python'
print(x[0:3])
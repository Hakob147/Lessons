# Write a Python function to get a string made of 4 copies of the last two characters of a
# specified string (length must be at least 2)

#Sample 'Exercises'

x='Exercises'
print(x[-2:]*4)

# Print the even numbers from 0 to 20 using a for loop and the range function

for n in range(0, 21):
    if n%2==0:
        print(n)
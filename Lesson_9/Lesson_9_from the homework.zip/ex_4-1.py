# Print the multiplication table of 5 using a for loop and f”strings”. The table should be
# printed up to 10.

for n in range(1,11):
    print(f"5 * {n} = ", 5*n)
# Write a for loop that iterates through a range(0,10) and prints every item

for n in range(0,11):
    print(n)
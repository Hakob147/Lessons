# Write a for loop which counts the square of each number to the new range(0,10)

list_1 = []
for n in range(0,10):
    list_1.append(n**2)
print(list_1)
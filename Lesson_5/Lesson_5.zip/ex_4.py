#Write a Python program to find the second smallest number in a list

list_1 = [3, 2, 1, 4, 5, 6]
sorted_list = (sorted(list_1))
print(sorted_list[1])



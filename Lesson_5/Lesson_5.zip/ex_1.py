# Write a Python program to multiply all the items in a list.

list_1 = [1, 5, 6, 7]
result = 1
for x in list_1:
    result *= x
print(result)









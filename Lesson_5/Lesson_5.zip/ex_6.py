# Turn every item of a list into its square

list_1 = [5, 7, 3, 9, 11]
for n in list_1:
     print(n**2)